import React from 'react'

const AboutBeauty = () => {
  return (
    <div>About Beauty</div>
  )
}

export default AboutBeauty