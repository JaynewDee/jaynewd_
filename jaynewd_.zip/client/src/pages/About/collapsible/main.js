import { Truth } from './Truth/Truth'

export { Truth };