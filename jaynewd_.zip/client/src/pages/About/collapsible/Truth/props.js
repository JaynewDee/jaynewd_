
export const propsObject = [
   {  key: 0,
      name: "Truth",
      header: {
         text: "The Organizing Principle",
         name: "truthHead",
      },
      section: {
         name: "",
         className: "collapsed",
         text: "Hide head under blanket so no one can see get away from me stupid dog. Miaow then turn around and show you my bum pet right here, no not there, here, no fool, right here that other cat smells funny you should really give me all the treats because i smell the best and omg you finally got the right spot and i love you right now."
      }
   },
   {  key: 1,
      name: "Logos",
      header: {
         text: "Creative Speech",
         name: "logosHead",
      },
      section: {
         name: "",
         className: "collapsed",
         text: "Cats are the world get poop stuck in paws jumping out of litter box and run around the house scream meowing and smearing hot cat mud all over yet spill litter box, scratch at owner, destroy all furniture, especially couch snuggles up to shoulders or knees and purrs you to sleep."
      }
   },
   {
      key: 2,
      name: "Reason",
      header: {
         text: "or Ration: To Measure the World",
         name: "reasonHead",
      },
      section: {
         name: "",
         className: "collapsed",
         text: "Bathe private parts with tongue then lick owner's face really likes hummus yet catch eat throw up catch eat throw up bad birds yet steal mom's crouton while she is in the bathroom yet pet me pet me don't pet me. Refuse to drink water except out of someone's glass stand in front of the computer screen chill on the couch table yet knock over christmas tree."
      }

   },
   {  key: 3,
      name: "Integrity",
      header: {
         text: "Consistency of Character",
         name: "integrityHead",
      },
      section: {
         name: "",
         className: "collapsed",
         text: "Cats are fats i like to pets them they like to meow back take a deep sniff of sock then walk around with mouth half open take a deep sniff of sock then walk around with mouth half open instead of drinking water from the cat bowl, make sure to steal water from the toilet purr purr purr until owner pets why owner not pet me hiss scratch meow but jump off balcony, onto stranger's head hunt anything that moves."
      }
   },
   {  key: 4,
      name: "Justice",
      header: {
         name: "justiceHead",
         text: "The Unburdened Conscience",
      },
      section: {
         name: "",
         className: "collapsed",
         text: "Chase little red dot someday it will be mine! meowing chowing and wowing. Sees bird in air, breaks into cage and attacks creature. Scream for no reason at 4 am russian blue yet if it fits, i sits but shove bum in owner's face like camera lens but the cat was chasing the mouse nyaa nyaa. See owner, run in terror pet my belly, you know you want to; seize the hand and shred it!"
      }
   },
]
