import React from 'react'

const AboutGoodness = () => {
  return (
    <div>About Goodness</div>
  )
}

export default AboutGoodness