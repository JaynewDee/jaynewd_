import React from 'react'

const ProjectsMain = () => {
   const left = 'floatLeft'
   const right = 'floatRight'
  return (
    <div className="projectBox">
       <div className="underSlide">
          <h3>Projects Main</h3>
          <p className={left}>
         Hiss at vacuum cleaner. Miaow then turn around and show you my bum step on your keyboard while you're gaming and then turn in a circle lick butt and    make a weird face, but chase after silly colored fish toys around the house so eat my own ears. Mark territory.
         </p>
         <p className={right}>
         Purrrrrr woops poop hanging from butt must get rid run run around house drag poop on floor maybe it comes off woops left brown marks on floor human  slave clean lick butt now or fooled again thinking the dog likes me eat my own ears love you, then bite you. Sit as close as possible to warm fire  without sitting on cold floor meow meow.
         </p>
         <p className={left}>Take a deep sniff of sock then walk around with mouth half open always ensure to lay down in such a manner that tail can lightly brush human's nose and warm up laptop with butt lick butt fart rainbows until owner yells pee in litter box hiss at cats mew mew.</p>
         <p className={right}>Chase little red dot someday it will be mine! meowing chowing and wowing. Sees bird in air, breaks into cage and attacks creature. Scream for no reason at 4 am russian blue yet if it fits, i sits but shove bum in owner's face like camera lens but the cat was chasing the mouse nyaa nyaa. See owner, run in terror pet my belly, you know you want to; seize the hand and shred it! 
         </p>
         
       </div>
    </div>
  )
}

export default ProjectsMain;