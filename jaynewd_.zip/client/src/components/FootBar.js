import React from 'react'

const FootBar = () => {
  return (
    <div id="footBox">FootBar</div>
  )
}

export default FootBar;