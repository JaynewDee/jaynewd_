import React from 'react'

const UtilityBar = () => {
  return (
     
    <div id="utilityBox">
       <button className="utilityBtn"><span className="buttonTextVert">ADMIN</span></button>
       <button style={{textAlign: "right"}}className="utilityBtn"><span className="buttonTextVert">ADMIN</span></button>
       <button className="utilityBtn"><span className="buttonTextVert">ADMIN</span></button>

    </div>
  )
}

export default UtilityBar;